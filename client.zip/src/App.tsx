import { Navigate, Route, Routes } from 'react-router-dom';
import HomePage from './pages/HomePage';
import EventsPage from './pages/EventsPage';
import EventDetailPage from './pages/EventDetailPage';
import AthletesPage from './pages/AthletesPage';
import AthleteProfilePage from './pages/AthleteProfilePage';
import SignInPage from './pages/SignInPage';
import RegisterPage from './pages/RegisterPage';
import AdminPage from './pages/AdminPage';
import { AppDataProvider } from './context/AppDataContext';

export default function App() {
  return <AppDataProvider><Routes>
    <Route path="/" element={<HomePage />} />
    <Route path="/events" element={<EventsPage />} />
    <Route path="/events/:eventId" element={<EventDetailPage />} />
    <Route path="/athletes" element={<AthletesPage />} />
    <Route path="/athletes/:employeeId" element={<AthleteProfilePage />} />
    <Route path="/signin" element={<SignInPage />} />
    <Route path="/register" element={<RegisterPage />} />
    <Route path="/admin" element={<AdminPage />} />
    <Route path="*" element={<Navigate to="/" replace />} />
  </Routes></AppDataProvider>;
}
