import { useState, type FormEvent } from 'react';
import { Link as RouterLink, useLocation, useNavigate } from 'react-router-dom';
import { Alert, Box, Button, Paper, TextField, Typography } from '@mui/material';
import Layout from '../components/Layout';
import { useAppData } from '../context/AppDataContext';

export default function SignInPage() {
  const [employeeId, setEmployeeId] = useState(''); const [error, setError] = useState(''); const { signIn } = useAppData(); const navigate = useNavigate(); const location = useLocation();
  const submit = (e: FormEvent) => { e.preventDefault(); const user = signIn(employeeId); if (!user) { setError('We could not find that employee ID. Check it or contact an administrator.'); return; } navigate(user.role === 'ADMIN' ? '/admin' : (location.state?.from || '/')); };
  return <Layout><Box className="auth-page"><Paper className="auth-card" elevation={0}><Typography className="overline">EMPLOYEE ACCESS</Typography><Typography variant="h1">Sign in</Typography><Typography color="text.secondary" fontSize={13}>Use your employee ID to access competitions, registrations and your athlete profile.</Typography>
    {location.state?.registered && <Alert severity="success" sx={{ mt: 2 }}>Athlete profile created. Sign in with your employee ID.</Alert>}
    {error && <Alert severity="error" sx={{ mt: 2 }}>{error}</Alert>}
    <Box component="form" onSubmit={submit} sx={{ mt: 3 }}><Typography className="form-label">Employee ID</Typography><TextField fullWidth placeholder="e.g. EMP001" size="small" value={employeeId} onChange={e => setEmployeeId(e.target.value.toUpperCase())} required autoFocus/><Button fullWidth variant="contained" type="submit" sx={{ mt: 2 }}>Continue</Button></Box>
    <Box className="demo-login-note"><b>Demo access</b><span>Athlete: EMP001 · Admin: ADM001</span><small>Demo sign-in uses employee ID only. Production must connect to company SSO or a verified authentication service.</small></Box>
    <Typography className="auth-foot">Not on the roster? <RouterLink to="/register">Request athlete access</RouterLink></Typography>
  </Paper></Box></Layout>;
}
